#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Samedi 26 Mars 2022 13:41
"""
from constantes import *


def dessiner_grille(grille: list) -> None:
    """
    Représenter la grille dans la console
        Args:
            grille (list) : tableau 2D qui représente le plateau de jeu
        Renvoi:
            rien
        Sortie:
            console
    """
    #préconditions
    assert type(grille) is list, "grille : mauvais type"
    assert len(grille) != 0, "grille : erreur de dimension"
    assert len(grille[0]) != 0, "grille : erreur de dimension"
    
    # Traitement / sortie
    for l in range(HAUTEUR):
        # print("-"*10)
        for c in range(LARGEUR):
            print(dessiner_jeton(grille, l, c), end="")
        print("|")


def dessiner_jeton(grille: list, l: int, c: int) -> str:
    """
    Représenter un jeton dans la console
        Args:
            grille (list) : tableau 2D qui représente le plateau de jeu
            l (int) : position en largeur
            c (int) : position en largeur
        Renvoi:
            (str) : une partie de la grille avec un jeton
    """
    #préconditions
    assert type(grille) is list, "grille : mauvais type"
    assert len(grille) != 0, "grille : erreur de dimension"
    assert len(grille[0]) != 0, "grille : erreur de dimension"
    assert type(c) is int, "Erreur de type"
    assert 0 <= c <= LARGEUR-1, "Erreur de domaine"
    assert type(l) is int, "Erreur de type"
    assert 0 <= l <= HAUTEUR-1, "Erreur de domaine"
    
    # Traitement / sortie
    return "|"+couleur_jeton(grille[l][c])



def couleur_jeton(jeton: int) -> str:
    """
    Changer la couleur du jeton
        Args:
            jeton (int) : couleur du jeton
                        pas de jeton = 0, ROUGE = 1, JAUNE = 2
        Renvoi:
            (str) : "J", "R" ou " " selon la couleur du jeton
    """
    # tests de développement
    #f = open('sortie.log','a')
    #print(f"couleur_jeton : jeton = {jeton}", file=f)
    
    
    #préconditions
    assert type(jeton) is int, "Erreur de type"
    assert jeton in [VIDE, ROUGE, JAUNE], "Erreur de domaine"
    
    # Traitement 
    if jeton == JAUNE:
        return "J"
    elif jeton == ROUGE:
        return "R"
    else:
        return " "


def afficher_gagnant(joueur: int) -> None:
    """
    crée la phrase pour le gagnant

    Args:
        joueur (int): le joueur gagnant
    Renvoi:
        rien
    Sortie:
        Dans la console
    """
    #préconditions
    assert type(joueur) is int, "Erreur de type"
    assert joueur in [1, 2], "Erreur de domaine"
    
    if joueur == ROUGE:
        couleur = "rouge"
    else:
        couleur = "jaune"
    print(f"Le joueur {couleur} a gagné.")



