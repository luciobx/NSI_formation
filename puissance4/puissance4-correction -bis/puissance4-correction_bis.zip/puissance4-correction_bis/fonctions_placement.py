#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Jeudi 25 Novembre 2021 12:29
"""
from constantes import *


def choisir_colonne() -> int:
    """
    demande la colonne
    vérifie si on ne sort pas de la grille

    Returns:
        (int): la colonne choisie
    """    
    col = LARGEUR #valeur trop grande
    while col<0 or col>=LARGEUR:
        #col = int(input("Dans quelle colonne placez-vous le jeton? "))
        try :
            col = int(input("Dans quelle colonne placez-vous le jeton? "))
        except ValueError:
            print("Entrer un nombre entier")
    return col


def changer_joueur(joueur: int) -> int:
    """
    passe la main à l'autre joueur

    Args:
        joueur (int): joueur en cours

    Returns:
        int: l'autre joueur
    """
    # tests de développement
    #f = open('sortie.log','a')
    #print(f"changer_joueur : joueur = {joueur}", file=f)
    
    # Préconditions
    assert type(joueur) is int, "Erreur de type"
    assert joueur in [1, 2], "joueur : erreur de domaine"
    
    return joueur % 2+1


def initialiser_grille(col: int, lig: int) -> list:
    """
    construire la grille du jeu. 
    Une place vide est marquée par un zéro.

    Args:
        col (int): nombre de colonnes
        lig (int): nombre de lignes

    Returns:
        list: un tableau de lig tableaux contenant chacun col zéros.
    """
    #f = open('sortie.log','a')
    #print(f"col : {col} lig : {lig}", file=f)
    
    # Préconditions
    assert type(col) is int, "Erreur de type"
    assert 0 < col <= LARGEUR, "Erreur de domaine"
    assert type(lig) is int, "Erreur de type"
    assert 0 < lig <= HAUTEUR, "Erreur de domaine"
    
    return [[VIDE for i in range(col)] for j in range(lig)]


def est_remplie(grille: list, colonne: int) -> bool:
    """
    vérifie si la colonne est remplie jusqu'en haut

    Args:
        grille (list): le jeu
        colonne (int): la colonne

    Returns:
        (bool): True si la colonne est remplie
    """
    # Préconditions
    assert type(grille) is list, "Erreur de type"
    assert len(grille) != 0, "Erreur de domaine"
    assert len(grille[0]) != 0, "Erreur de domaine"
    assert type(colonne) is int, "Erreur de type"
    assert 0 <= colonne <= LARGEUR-1, "Erreur de domaine"
    
    
    # il suffit de vérifier si l'emplacement le plus haut est vide
    return not(grille[0][colonne] == VIDE)


def placer_jeton(grille: list, col: int, joueur: int) -> int:
    """
    place le jeton dans la colonne choisie 
    en le faisant descendre dans la ligne 
    la plus basse possible 
    Args:
        grille (list): le jeu
        col (int): la colonne
        joueur (int): la couleur du joueur
    Returns:
        (int): la ligne où le jeton est placé 
    """
    
    # Préconditions
    assert type(grille) is list, "Erreur de type"
    assert len(grille) != 0, "Erreur de domaine"
    assert len(grille[0]) != 0, "Erreur de domaine"
    assert type(col) is int, "Erreur de type"
    assert 0 <= col <= LARGEUR-1, "Erreur de domaine"
    assert type(joueur) is int, "Erreur de type"
    assert joueur in [1, 2], "joueur : erreur de domaine"
    
    # Traitement / sortie
    
    lig = 0
    # on n'est pas en bas ni sur une case remplie
    while lig+1 < HAUTEUR and grille[lig+1][col] == VIDE:
        lig = lig + 1

    # place le jeton du joueur
    grille[lig][col] = joueur
    
    # Postconditions
    assert type(lig) is int, "Erreur de type"
    assert 0 <= lig <= LARGEUR - 1, "Erreur de domaine"
    
    return lig


if __name__ == "__main__":
    
    # ---- Test 1 ----
    """
    # si main : provoque une erreur
    # si module : ne provoque pas d'erreur, non appelé
    placer_jeton([], LARGEUR, ROUGE)
    """
    
    # ---- Test 2 ----
    import pprint
    grille_test = [ [VIDE for i in range(LARGEUR)]
                    for j in range(HAUTEUR) ]
    # rempli la première colonne
    for i in range(HAUTEUR):
        grille_test[i][0] = JAUNE
    # place 2 jetons dans colonne 3
    grille_test[5][3] = JAUNE
    grille_test[4][3] = JAUNE
    pprint.pprint(grille_test)
    print( est_remplie(grille_test, 0) )
    print( est_remplie(grille_test, 3) )
    
    # ---- Test 3 ----
    grille_test = [ [VIDE for i in range(LARGEUR)]
                    for j in range(HAUTEUR) ]
    # rempli la première colonne
    for i in range(HAUTEUR):
        grille_test[i][0] = JAUNE
    # place 2 jetons dans colonne 3
    grille_test[5][3] = JAUNE
    grille_test[4][3] = JAUNE
    # Tests
    assert est_remplie(grille_test, 0)
    assert est_remplie(grille_test, 1) == False
    assert est_remplie(grille_test, 2) == False
    assert est_remplie(grille_test, 3) == False
    assert est_remplie(grille_test, 4) == False
    assert est_remplie(grille_test, 5) == False
    
    

    
    
