#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Jeudi 25 Novembre 2021 12:27
"""

LARGEUR = 7
HAUTEUR = 6
VIDE = 0
ROUGE = 1
JAUNE = 2
TAILLE = 100
MARGE = 10
