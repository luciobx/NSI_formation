# By Luc VINCENT 
# 2022.04.05
# module init
# 1.0
# luc.vincent@ac-bordeaux.fr
# sys.version '3.7.9 (tags/v3.7.9:13c94747c7, Aug 17 2020, 18:01:55) [MSC v.1900 32 bit (Intel)]'

# Initialiser le jeu
def initialise(max_trials:int, box_max:int, box_min:int)->list:
    '''
    Renvoyer  des valeurs valides choisies par l'utilisateur 
    max_trials : int Nombre d'essais maxi acceptable
    box_max : int Nombre maxi de case
    box_min : int Nombre mini de case
    CU : Valeurs limite arguments MAX_TRIALS, BOX_MAX, MAX_TRIALS"
    except : assertionError
    answer : list of int [width, heigth, trials] choisis par l'utilisateur
    '''
    # préconditions
    assert isinstance(max_trials, int)\
           and type(box_max) is int \
           and type(box_min) is int, "Argument entiers SVP"
    assert max_trials <= MAX_TRIALS \
           and box_max <= BOX_MAX \
           and box_min >= BOX_MIN, "Valeurs limite arguments dépassée"
    
    # traitement
    answer = [0, 0, 0]
    
    while answer[2] == 0:
        while answer[0] == 0 :
            try :
                answer[0]  = abs(int(input("Entrer la largeur de la grille : ")))
            except ValueError:
                print("Entrer un nombre entier")
        
        while answer[1] == 0 :
            try :
                answer[1] = abs(int(input("Entrer la hauteur de la grille : ")))
            except ValueError:
                print("Entrer un nombre entier")
        # Controle grille
        if BOX_MIN <= (answer[0] * answer[1]) <= BOX_MAX :
            answer[2] = -1
        else:
            print(f"Votre choix de largeur {answer[0]} x hauteur {answer[1]} ne convient pas")
            print(f"Le choix {answer[0]*answer[1]} cases, n'est pas compris entre {BOX_MIN} et {BOX_MAX}")
            answer = [0, 0, 0]
    while answer[2] == -1 :
            try :
                answer[2]  = abs(int(input("Entrer le nombre d'essais : ")))
            except ValueError:
                print("Entrer un nombre entier")
            if answer[2] > MAX_TRIALS:
                print(f"Votre choix de {answer[2]} n'est pas inférieur à {MAX_TRIALS}")
                answer[2] = -1
       
    # post conditions
    assert type(answer) is list, "type renvoyé non conforme"
    assert len(answer)== 3, "type renvoyé non conforme"
    for i in range(3):
        assert type(answer[i]) is int, "type renvoyé non conforme"
    
    return answer

if __name__ == "__main__":
    # exemple de test
    from constants import * 
    assert initialise(100, 64, 4) == [1, 5, 7] # Utilisateur entre 1, 5, 7