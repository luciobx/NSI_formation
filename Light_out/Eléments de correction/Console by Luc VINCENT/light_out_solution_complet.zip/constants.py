# By Luc VINCENT 
# 2022.04.05
# module light_out
# 1.0
# luc.vincent@ac-bordeaux.fr
# sys.version '3.7.9 (tags/v3.7.9:13c94747c7, Aug 17 2020, 18:01:55) [MSC v.1900 32 bit (Intel)]'

BOX_MIN = 4 # Nombre minimum de cases de la grille
BOX_MAX = 64 # Nombre maximum de cases de la grille
MAX_TRIALS = 100 # Nombre d'essais acceptables